package com.jdbc.project2;





	import java.sql.*;
	import java.util.Scanner;

	//Class to represent a customer
	class Customer {
	    private String custName;
	    private String password;
	    private double balance;

	    // Constructor
	    public Customer(String custName, String password, double balance) {
	        this.custName = custName;
	        this.password = password;
	        this.balance = balance;
	    }

	    // Getters and setters
	    public String getCustName() {
	        return custName;
	    }

	    public String getPassword() {
	        return password;
	    }

	    public double getBalance() {
	        return balance;
	    }

	    // Method to deposit amount
	 // Method to deposit amount for a specific customer
	    public boolean deposit(Connection connection,String custName, double amount) {
	        String updateQuery = "UPDATE customer SET Balance = Balance + ? WHERE customerName = ?";
	        try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
	            preparedStatement.setDouble(1, amount);
	            preparedStatement.setString(2, custName);
	            int rowsUpdated = preparedStatement.executeUpdate();
	            connection.commit();
	            if (rowsUpdated > 0) {
	                // Update the balance attribute of the Customer object after a successful deposit
	                this.balance += amount;
	                System.out.println("Current Balance = " + this.balance);
	                return true;
	            } else {
	                return false;
	            }
	         
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }


	    // Method to withdraw amount
	 // Method to withdraw amount for a specific customer
	    public boolean withdraw( Connection connection,String custName, double amount) {
	        String updateQuery = "UPDATE customer SET Balance = Balance - ? WHERE customerName = ? AND Balance >= ?";
	        try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
	            preparedStatement.setDouble(1, amount);
	            preparedStatement.setString(2, custName);
	            preparedStatement.setDouble(3, amount); // Ensure sufficient balance
	            int rowsUpdated = preparedStatement.executeUpdate();
	            connection.commit();
	            if (rowsUpdated > 0) {
	                // Update the balance attribute of the Customer object after a successful withdrawal
	                this.balance -= amount;
	                System.out.println("Current Balance = " + this.balance);
	                return true;
	            } else {
	                return false;
	            }
	           
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }

	    }

	//Class to handle database operations
	class DatabaseStoring {
	   public Connection connection;
	   public Connection getConnection() {
	       return connection;
	   }

	    // Constructor
	    public DatabaseStoring() {
	        String url="jdbc:mysql://localhost:3306/employees";
	        String userName="root";
	        String password="root";
	        try {
	            
	                Class.forName("com.mysql.cj.jdbc.Driver");
	            
	                
	                
	            connection = DriverManager.getConnection(url, userName, password);

	            createTableIfNotExists(); // Call table creation method
	            connection.setAutoCommit(false);

	        } 
	        catch (ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	        catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    // Method to create customer table if not exists
	    private void createTableIfNotExists() {
	        String query = "CREATE TABLE IF NOT EXISTS customer (" +
	                       "id INT AUTO_INCREMENT PRIMARY KEY," +
	                       "customerName VARCHAR(45)," +
	                       "Password VARCHAR(45)," +
	                       "Balance DECIMAL(10,2))";
	        try (Statement statement = connection.createStatement()) {
	            statement.executeUpdate(query);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    // Method to add a new customer to the database
	    public boolean addCustomer(Customer customer) {
	        String query = "INSERT INTO customer (customerName, Password, Balance) VALUES (?, ?, ?)";
	        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
	            preparedStatement.setString(1, customer.getCustName());
	            preparedStatement.setString(2, customer.getPassword());
	            preparedStatement.setDouble(3, customer.getBalance());
	            int rowsInserted = preparedStatement.executeUpdate();
	            connection.commit();
	            return rowsInserted > 0;
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }

	    // Method to retrieve customer by name and password
	 // Method to retrieve customer by name and password
	    public Customer getCustomer(String custName, String password) {
	        String query = "SELECT * FROM customer WHERE customerName = ? AND password = ?";
	        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
	            preparedStatement.setString(1, custName);
	            preparedStatement.setString(2, password);
	            ResultSet resultSet = preparedStatement.executeQuery();
	            if (resultSet.next()) {
	                double balance = resultSet.getDouble("Balance");
	                return new Customer(custName, password, balance);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return null;
	    }


	    // Method to close connection
	    public void closeConnection() {
	        try {
	            if (connection != null) {
	                connection.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	}

	//Main class to represent the application
	public class Demo1 {
	    private static final DatabaseStoring dbHandler = new DatabaseStoring();
	    private static final Scanner scanner = new Scanner(System.in);

	    public static void main(String[] args) {
	        boolean exit = false;

	        while (!exit) {
	            System.out.println("Customer");
	            System.out.println("1. Customer Login");
	            System.out.println("2. New Customer Sign in");
	            System.out.println("3. Exit");
	            System.out.print("Enter your choice: ");
	            int choice = scanner.nextInt();

	            switch (choice) {
	                case 1:
	                    Customer customer = customerLogin();
	                    if (customer != null) {
	                        customerMenu(customer);
	                    } else {
	                        System.out.println("Invalid credentials. Please try again.");
	                    }
	                    break;
	                case 2:
	                    signUp();
	                    break;
	                case 3:
	                    exit = true;
	                    System.out.println("Exited Application successfully...");
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please enter a valid option.");
	            }
	        }
	        dbHandler.closeConnection();
	        scanner.close();
	    }


	    // Method to handle customer login
	    private static Customer customerLogin() {
	        System.out.print("Enter customer name: ");
	        String custName = scanner.next();
	        System.out.print("Enter password: ");
	        String password = scanner.next();
	        return dbHandler.getCustomer(custName, password);
	    }

	    // Method to handle customer sign up
	    private static void signUp() {
	        System.out.print("Enter customer name: ");
	        String custName = scanner.next();
	        System.out.print("Enter password: ");
	        String password = scanner.next();
	        
			Customer newCustomer = new Customer(custName, password, 0.0);
	        boolean success = dbHandler.addCustomer(newCustomer);
	        if (success) {
	            System.out.println("Sign up successful. Please log in to continue.");
	        } else {
	            System.out.println("Error occurred during sign up. Please try again.");
	        }
	    }

	    // Method to handle customer menu
	    private static void customerMenu(Customer customer) {
	        boolean logout = false;

	        while (!logout) {
	            System.out.println("\nAccount Details");
	            System.out.println("a. Amount Deposit");
	            System.out.println("b. Amount Withdrawal");
	            System.out.println("c. Check Balance");
	            System.out.println("d. Exit");
	            System.out.print("Enter your choice: ");
	            char option = scanner.next().charAt(0);

	            switch (option) {
	                case 'a':
	                    System.out.print("Enter amount to deposit: ");
	                    double depositAmount = scanner.nextDouble();
	                    boolean depositSuccess = customer.deposit(dbHandler.getConnection(), customer.getCustName(), depositAmount);
	                    if (depositSuccess) {
	                        System.out.println("Deposit successful.");
	                    } else {
	                        System.out.println("Error occurred during deposit. Please try again.");
	                    }
	                    break;

	                case 'b':
	                    System.out.print("Enter amount to withdraw: ");
	                    double withdrawAmount = scanner.nextDouble();
	                    boolean withdrawSuccess = customer.withdraw(dbHandler.getConnection(), customer.getCustName(), withdrawAmount);
	                    if (withdrawSuccess) {
	                        System.out.println("Withdrawal successful.");
	                    } else {
	                        System.out.println("Error occurred during withdrawal. Insufficient funds or invalid amount.");
	                    }
	                    break;

	                case 'c':
	                    System.out.println("Current Balance: " + customer.getBalance());
	                    break;

	                case 'd':
	                    logout = true;
	                    break;

	                default:
	                    System.out.println("Invalid option. Please enter a valid option.");
	            }
	        }
	    }

	        
	    }



